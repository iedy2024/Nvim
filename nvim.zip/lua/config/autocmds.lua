local group = vim.api.nvim_create_augroup("UserConfig", { clear = true })
local autocmd = vim.api.nvim_create_autocmd

autocmd("TextYankPost", {
    group = group,
    callback = function()
        vim.hl.on_yank({ higroup = "IncSearch", timeout = 40 })
    end,
})

-- Strip trailing whitespace on save
autocmd("BufWritePre", {
    group = group,
    command = [[%s/\s\+$//e]],
})

-- LSP keymaps, only in buffers with a server attached
autocmd("LspAttach", {
    group = group,
    callback = function(e)
        local map = function(mode, lhs, rhs, desc)
            vim.keymap.set(mode, lhs, rhs, { buffer = e.buf, desc = desc })
        end
        map("n", "gd", vim.lsp.buf.definition, "Go to definition")
        map("n", "K", vim.lsp.buf.hover, "Hover docs")
        map("n", "<leader>vws", vim.lsp.buf.workspace_symbol, "Workspace symbols")
        map("n", "<leader>vca", vim.lsp.buf.code_action, "Code action")
        map("n", "<leader>vrr", vim.lsp.buf.references, "References")
        map("n", "<leader>vrn", vim.lsp.buf.rename, "Rename")
        map("n", "<leader>lr", "<cmd>LspRestart<CR>", "Restart LSP")
        map("i", "<C-h>", vim.lsp.buf.signature_help, "Signature help")
    end,
})
