local opt = vim.opt

opt.guicursor = ""
opt.number = true
opt.relativenumber = true

opt.tabstop = 4
opt.softtabstop = 4
opt.shiftwidth = 4
opt.expandtab = true
opt.smartindent = true

opt.wrap = false
opt.scrolloff = 8
opt.signcolumn = "yes"
opt.colorcolumn = "80"
opt.termguicolors = true

opt.swapfile = false
opt.backup = false
opt.undodir = vim.fn.stdpath("state") .. "/undo"
opt.undofile = true

opt.hlsearch = false
opt.incsearch = true

opt.isfname:append("@-@")
opt.updatetime = 50

vim.g.netrw_browse_split = 0
vim.g.netrw_banner = 0
vim.g.netrw_winsize = 25
