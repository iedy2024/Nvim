return {
  {
    "MeanderingProgrammer/render-markdown.nvim",
    dependencies = {
      "nvim-treesitter/nvim-treesitter",
      "nvim-tree/nvim-web-devicons", -- drop if you don't use devicons
    },
    ft = { "markdown" },
    ---@module 'render-markdown'
    ---@type render.md.UserConfig
    opts = {
      -- render everywhere except insert mode, so editing shows raw text
      render_modes = { "n", "v", "i", "c" },
      anti_conceal = { enabled = true }, -- unconceal the line under the cursor

      heading = {
        sign = false,
        icons = { "󰲡 ", "󰲣 ", "󰲥 ", "󰲧 ", "󰲩 ", "󰲫 " },
        width = "block",
        left_pad = 0,
        right_pad = 2,
      },

      code = {
        sign = false,
        style = "full",   -- language name + icon in the top border
        width = "block",
        left_pad = 2,
        right_pad = 2,
        border = "thin",
      },

      bullet = {
        icons = { "•", "◦", "▪", "▫" },
      },

      checkbox = {
        unchecked = { icon = "󰄱 " },
        checked   = { icon = "󰱒 " },
      },

      dash = { width = 80 },

      link = { enabled = true },
    },
    keys = {
      { "<leader>tm", "<cmd>RenderMarkdown toggle<cr>", desc = "Toggle markdown render" },
    },
  },
}
