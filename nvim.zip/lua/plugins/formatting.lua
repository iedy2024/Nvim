return {
    "stevearc/conform.nvim",
    event = "BufWritePre",
    keys = {
        { "<leader>f", function() require("conform").format({ bufnr = 0 }) end, desc = "Format buffer" },
    },
    opts = {
        format_on_save = {
            timeout_ms = 5000,
            lsp_format = "fallback", -- e.g. Java has no entry, so jdtls formats it
        },
        formatters_by_ft = {
            c = { "clang-format" },
            cpp = { "clang-format" },
            python = { "ruff_format" },
            lua = { "stylua" },
            go = { "gofmt" },
            javascript = { "prettier" },
            typescript = { "prettier" },
        },
        formatters = {
            ["clang-format"] = {
                prepend_args = { "-style=file", "-fallback-style=LLVM" },
            },
        },
    },
}
