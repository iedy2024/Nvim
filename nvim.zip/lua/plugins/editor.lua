return {
    {
        "mbbill/undotree",
        keys = { { "<leader>u", vim.cmd.UndotreeToggle, desc = "Undotree" } },
    },

    {
        "folke/trouble.nvim",
        cmd = "Trouble",
        opts = {},
        keys = {
            { "<leader>tt", "<cmd>Trouble diagnostics toggle<cr>", desc = "Diagnostics list" },
            { "]t", function() require("trouble").next({ skip_groups = true, jump = true }) end, desc = "Next trouble item" },
            { "[t", function() require("trouble").prev({ skip_groups = true, jump = true }) end, desc = "Prev trouble item" },
        },
    },

    {
        "folke/zen-mode.nvim",
        keys = {
            { "<leader>zz", function()
                require("zen-mode").toggle({ window = { width = 90 } })
                vim.wo.wrap = false
            end, desc = "Zen mode" },
        },
    },

    {
        -- Hides secret values in .env-style files
        "laytan/cloak.nvim",
        opts = {
            cloak_character = "*",
            highlight_group = "Comment",
            patterns = {
                { file_pattern = { ".env*", "wrangler.toml", ".dev.vars" }, cloak_pattern = "=.+" },
            },
        },
    },
}
