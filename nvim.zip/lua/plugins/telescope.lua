return {
    "nvim-telescope/telescope.nvim",
    version = "*",
    dependencies = { "nvim-lua/plenary.nvim" },
    config = function()
        require("telescope").setup({})
        local builtin = require("telescope.builtin")
        local map = vim.keymap.set

        map("n", "<leader>pf", builtin.find_files, { desc = "Find files" })
        map("n", "<C-p>", builtin.git_files, { desc = "Find git files" })
        map("n", "<leader>ps", function()
            builtin.grep_string({ search = vim.fn.input("Grep > ") })
        end, { desc = "Grep" })
        map("n", "<leader>pws", function()
            builtin.grep_string({ search = vim.fn.expand("<cword>") })
        end, { desc = "Grep word" })
        map("n", "<leader>pWs", function()
            builtin.grep_string({ search = vim.fn.expand("<cWORD>") })
        end, { desc = "Grep WORD" })
        map("n", "<leader>vh", builtin.help_tags, { desc = "Help tags" })
    end,
}
