return {
    "tpope/vim-fugitive",
    cmd = { "Git", "G" },
    keys = {
        { "<leader>gs", vim.cmd.Git, desc = "Git status" },
        { "gu", "<cmd>diffget //2<CR>", desc = "Diffget left" },
        { "gh", "<cmd>diffget //3<CR>", desc = "Diffget right" },
    },
    config = function()
        vim.api.nvim_create_autocmd("FileType", {
            group = vim.api.nvim_create_augroup("UserFugitive", { clear = true }),
            pattern = "fugitive",
            callback = function(e)
                local opts = { buffer = e.buf }
                vim.keymap.set("n", "<leader>p", function() vim.cmd.Git("push") end, opts)
                vim.keymap.set("n", "<leader>P", function() vim.cmd.Git({ "pull", "--rebase" }) end, opts)
                vim.keymap.set("n", "<leader>t", ":Git push -u origin ", opts)
            end,
        })
    end,
}
