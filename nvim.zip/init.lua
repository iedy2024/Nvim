require("config.options")
require("config.keymaps")   -- sets <leader> before plugins load
require("config.lazy")
require("config.autocmds")
